//
//  WeatherNetManager.h
//  BaseProject
//
//  Created by apple-jd40 on 15/11/25.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "WeatherModel.h"
@interface WeatherNetManager : BaseNetManager

+ (id)getWeatherDataWithCity:(NSString *)city completionHandle:(void(^)(WeatherModel *model , NSError *error))complete;


@end
