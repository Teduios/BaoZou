//
//  WeatherNetManager.m
//  BaseProject
//
//  Created by apple-jd40 on 15/11/25.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "WeatherNetManager.h"

@implementation WeatherNetManager

+ (id)getWeatherDataWithCity:(NSString *)city completionHandle:(void(^)(WeatherModel *model , NSError *error))complete{
    NSString *cityStr = [city stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSString *path = [NSString stringWithFormat:@"http://wthrcdn.etouch.cn/weather_mini?city=%@",cityStr];
    return [WeatherNetManager GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        complete([WeatherModel objectWithKeyValues:responseObj],error);
    }];
}

@end

























