//
//  WeatherViewModel.m
//  BaseProject
//
//  Created by apple-jd40 on 15/11/25.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "WeatherViewModel.h"

@implementation WeatherViewModel

- (NSString *)getDateWithType:(MyDate)type{
    return [self modelForTodayForType:type].date;
}
- (NSString *)getFengliWithType:(MyDate)type{
    return [self modelForTodayForType:type].fengli;
}
- (NSString *)getFengxiangWithType:(MyDate)type{
    return [self modelForTodayForType:type].fengxiang;
}
- (NSString *)getHighTemperatureWithType:(MyDate)type{
    return [self modelForTodayForType:type].high;
}
- (NSString *)getLowTemperatureWithType:(MyDate)type{
    return [self modelForTodayForType:type].low;
}
- (NSString *)getTypeWithType:(MyDate)type{
    return [self modelForTodayForType:type].type;
}

- (NSString *)getNowTempetatureWithType:(MyDate)type{
    return self.weatherData.wendu;
}
/** 根据天气获取图片 */
- (UIImage *)getImageForTypeWithType:(MyDate)type{
    //获取天气状况(晴. 多云...)
    NSString *weather= [self getTypeWithType:type];
    if ([weather isEqualToString:@"雷阵雨"]) {
        return [UIImage imageNamed:@"thunder"];
    }else if ([weather isEqualToString:@"晴"]){
        return  [UIImage imageNamed:@"sun"];
    }else if ([weather isEqualToString:@"多云"]){
        return  [UIImage imageNamed:@"sunandcloud"];
    }else if ([weather isEqualToString:@"阴"]){
        return  [UIImage imageNamed:@"cloud"];
    }else if ([weather hasSuffix:@"雨"]){
        return  [UIImage imageNamed:@"rain"];
    }else if ([weather hasSuffix:@"雪"]){
        return  [UIImage imageNamed:@"snow"];
    }else{
        return  [UIImage imageNamed:@"sandfloat"];
    }

}

/** 根据需要的哪一天获取天气情况 */
- (WeatherDetailDataModel *)modelForTodayForType:(MyDate)type{
    if (self.dataArr.count>0) {
        return self.dataArr[type];
    }
    return nil;
}

- (void)refreshWeatherWithCity:(NSString *)city CompleteHandle:(void(^)(NSError *error))complete{
    [WeatherNetManager getWeatherDataWithCity:city completionHandle:^(WeatherModel *model, NSError *error) {
        self.weatherData = model.data;
        self.dataArr =[self.weatherData.forecast mutableCopy];
        complete(error);
    }];
}

@end
















