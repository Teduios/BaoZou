//
//  WeatherViewModel.h
//  BaseProject
//
//  Created by apple-jd40 on 15/11/25.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "WeatherNetManager.h"
//日期
typedef enum : NSUInteger {
    Today,
    Tomorrow,
    TheDayAfterTomorrow,
    ThreeDaysFromNow,
    FourDaysFromNow,
    FiveDaysFromNow
} MyDate;

@interface WeatherViewModel : BaseViewModel

@property (nonatomic, strong)  WeatherDataModel *weatherData;
/** 根据传入获取日期 */
- (NSString *)getDateWithType:(MyDate)type;
/** 获取风力 */
- (NSString *)getFengliWithType:(MyDate)type;
/** 获取风向 */
- (NSString *)getFengxiangWithType:(MyDate)type;
/** 获取最高气温 */
- (NSString *)getHighTemperatureWithType:(MyDate)type;
/** 获取最低气温 */
- (NSString *)getLowTemperatureWithType:(MyDate)type;
/** 获取天气描述(如:阴,晴...) */
- (NSString *)getTypeWithType:(MyDate)type;
/** 获取当前温度 */
- (NSString *)getNowTempetatureWithType:(MyDate)type;
/** 根据天气获取图片 */
- (UIImage *)getImageForTypeWithType:(MyDate)type;
/** 根据传入的城市名字更新天气详情 */
- (void)refreshWeatherWithCity:(NSString *)city CompleteHandle:(void(^)(NSError *error))complete;



@end













