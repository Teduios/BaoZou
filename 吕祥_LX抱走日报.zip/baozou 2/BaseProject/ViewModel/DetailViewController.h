//
//  DetailViewController.h
//  BaseProject
//
//  Created by apple-jd40 on 15/11/9.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"
@interface DetailViewController : BaseViewController

@property (nonatomic, strong) NSURL *url;

@end
