//
//  DetailViewController.m
//  BaseProject
//
//  Created by apple-jd40 on 15/11/9.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "DetailViewController.h"
#import "Factory.h"
@interface DetailViewController ()<UIWebViewDelegate>

@end

@implementation DetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"---详情---";
    self.view.backgroundColor = [[[NSUserDefaults standardUserDefaults] valueForKey:@"isNight"] integerValue]?[UIColor darkGrayColor]:[UIColor whiteColor];
    [Factory addBackItemToVC:self];
    UIWebView *webview = [[UIWebView alloc]init];
    webview.alpha = [[[NSUserDefaults standardUserDefaults] valueForKey:@"isNight"] integerValue]?0.7:1;
    //webview.backgroundColor = [UIColor clearColor];
    webview.scrollView.bounces = NO;
    [webview loadRequest:[NSURLRequest requestWithURL:self.url]];
    [self.view addSubview:webview];
    [webview mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.left.right.mas_equalTo(0);
        make.top.mas_equalTo(-45);
    }];
    webview.delegate = self;
}
- (void)webViewDidStartLoad:(UIWebView *)webView{
    [self showProgress];
}
- (void)webViewDidFinishLoad:(UIWebView *)webView{
    [self hideProgress];
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:YES];
    [[NSUserDefaults standardUserDefaults] removeObserver:self forKeyPath:@"isNight"];
}
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSString *,id> *)change context:(void *)context{
    self.view.backgroundColor = [change[@"new"] integerValue]?[UIColor darkGrayColor]:[UIColor whiteColor];
    
}


@end













