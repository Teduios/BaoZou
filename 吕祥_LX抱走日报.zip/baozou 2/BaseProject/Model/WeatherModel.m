//
//  WeatherModel.m
//  BaseProject
//
//  Created by apple-jd40 on 15/11/25.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "WeatherModel.h"
/**
 @interface WeatherModel
 @interface WeatherDataModel
 @interface WeatherYesterdayDataModel
 @interface WeatherDetailDataModel
 */
@implementation WeatherModel

@end

@implementation WeatherDataModel

+ (NSDictionary *)objectClassInArray{
    return @{@"forecast":[WeatherDetailDataModel class]};
}

@end

@implementation WeatherYesterdayDataModel



@end

@implementation WeatherDetailDataModel



@end





















