//
//  WeatherModel.h
//  BaseProject
//
//  Created by apple-jd40 on 15/11/25.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BaseModel.h"
@class WeatherDataModel,WeatherYesterdayDataModel,WeatherDetailDataModel;
@interface WeatherModel : BaseModel

@property (nonatomic, strong) NSString *desc;
@property (nonatomic, assign) double status;
@property (nonatomic, strong) WeatherDataModel *data;

@end
@interface WeatherDataModel : BaseModel

@property (nonatomic, strong) NSString *wendu;
@property (nonatomic, strong) NSArray *forecast;
@property (nonatomic, strong) NSString *ganmao;
@property (nonatomic, strong) WeatherYesterdayDataModel *yesterday;
@property (nonatomic, strong) NSString *aqi;
@property (nonatomic, strong) NSString *city;

@end

@interface WeatherYesterdayDataModel : BaseModel

@property (nonatomic, strong) NSString *low;
@property (nonatomic, strong) NSString *fl;
@property (nonatomic, strong) NSString *high;
@property (nonatomic, strong) NSString *type;
@property (nonatomic, strong) NSString *fx;
@property (nonatomic, strong) NSString *date;

@end

@interface WeatherDetailDataModel : BaseModel

@property (nonatomic, strong) NSString *fengli;
@property (nonatomic, strong) NSString *low;
@property (nonatomic, strong) NSString *high;
@property (nonatomic, strong) NSString *type;
@property (nonatomic, strong) NSString *fengxiang;
@property (nonatomic, strong) NSString *date;

@end
























