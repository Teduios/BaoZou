//
//  AppDelegate.m
//  BaseProject
//
//  Created by jiyingxin on 15/10/21.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "AppDelegate.h"
#import "AppDelegate+Category.h"
#import "ViewController.h"
#import "LeftViewController.h"
#import "DetailViewController.h"
#import "HotViewController.h"
#import "SectionListViewController.h"
#import "SectionDetailViewController.h"


@interface AppDelegate ()

@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    [self initializeWithApplication:application];
    self.window.rootViewController = self.sideMenu;
    return YES;
}

- (UIWindow *)window{
    if (!_window) {
        _window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
        [_window makeKeyAndVisible];
    }
    return _window;
}

- (RESideMenu *)sideMenu{
    if (!_sideMenu) {
        _sideMenu=[[RESideMenu alloc]initWithContentViewController:[[UINavigationController alloc] initWithRootViewController:[ViewController stander]] leftMenuViewController:[LeftViewController new] rightMenuViewController:nil];
        
        //为sideMenu设置背景图,图片插件KSImageName，到Github下载
//        _sideMenu.backgroundImage =[UIImage imageNamed:@"10979715_0800"];
        //可以让出现菜单时不显示状态栏
        _sideMenu.menuPrefersStatusBarHidden = YES;
        //不允许菜单栏到了边缘还可以继续缩小
        _sideMenu.bouncesHorizontally = NO;
        _sideMenu.scaleMenuView = NO;
        _sideMenu.scaleContentView = NO;
        _sideMenu.scaleBackgroundImageView = NO;
    }
    return _sideMenu;
}

@end
