//
//  HotListCell.h
//  BaseProject
//
//  Created by apple-jd40 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HotListCell : UITableViewCell

@property (nonatomic, strong) UIImageView *imv;
@property (nonatomic, strong) UILabel *titleLb;
@property (nonatomic, strong) UILabel *sectionLb;
@property (nonatomic, strong) UILabel *hitcountLb;


@end
