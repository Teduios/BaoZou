//
//  SectionCell.h
//  BaseProject
//
//  Created by apple-jd40 on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SectionCell : UITableViewCell

@property (nonatomic, strong) UIImageView *imv;
@property (nonatomic, strong) UILabel *descLb;
@property (nonatomic, strong) UILabel *nameLb;

@end
