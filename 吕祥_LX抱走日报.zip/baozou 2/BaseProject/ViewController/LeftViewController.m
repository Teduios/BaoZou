//
//  LeftViewController.m
//  BaseProject
//
//  Created by apple-jd40 on 15/11/12.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "LeftViewController.h"
#import "HotViewController.h"
#import "ViewController.h"
#import "SectionListViewController.h"
#import "DetailViewController.h"
#import "Factory.h"
#import "MoreTabBarController.h"

@interface LeftCell : UITableViewCell
@property (nonatomic, strong) UIImageView *imv;
@property (nonatomic, strong) UILabel *lable;
@end
@implementation LeftCell
- (UIImageView *)imv{
    if (_imv==nil) {
        _imv = [[UIImageView alloc]init];
        [self.contentView addSubview:_imv];
        [_imv mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(20);
            make.top.mas_equalTo(8);
            make.bottom.mas_equalTo(-8);
            make.size.mas_equalTo(CGSizeMake(20, 20));
        }];
    }
    return _imv;
}
- (UILabel *)lable{
    if (_lable == nil) {
        _lable = [UILabel new];
        [self.contentView addSubview:_lable];
        [_lable mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.mas_equalTo(0);
            make.left.mas_equalTo(self.imv.mas_right).mas_equalTo(40);
        }];
    }
    return _lable ;
}
@end

@interface LeftViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSArray *names;
@property (nonatomic, strong) UIView *redView;

@end

@implementation LeftViewController

- (UIView *)redView{
    if (_redView == nil) {
        _redView = [UIView new];
        _redView.backgroundColor = [[[NSUserDefaults standardUserDefaults] valueForKey:@"isNight"] integerValue]?[UIColor lightGrayColor]:[UIColor redColor];
        [self.view addSubview:_redView];
        [_redView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.right.mas_equalTo(0);
            make.bottom.mas_equalTo(self.tableView.mas_topMargin).mas_equalTo(-10);
        }];
        UIImageView *imv = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"login.png"]];
        [_redView addSubview:imv];
        [imv mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.mas_equalTo(0);
            make.left.mas_equalTo(50);
            make.size.mas_equalTo(CGSizeMake(70, 70));
        }];
        UILabel *label = [UILabel new];
        [_redView addSubview:label];
        [label mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.mas_equalTo(imv);
            make.top.mas_equalTo(imv.mas_bottomMargin).mas_equalTo(10);
        }];
        //label.text = @"登录";
        label.textColor = [UIColor blueColor];
        
    }
    return _redView;
}

- (UITableView *)tableView {
    if(_tableView == nil) {
        _tableView = [[UITableView alloc] init];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.backgroundColor = [UIColor clearColor];
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        [_tableView registerClass:[LeftCell class] forCellReuseIdentifier:@"Cell"];
        [self.view addSubview:_tableView];
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(kWindowW/2, kWindowH/2));
            make.centerY.mas_equalTo(0);
            make.left.mas_equalTo(0);
        }];
    }
    return _tableView;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view addSubview:self.redView];
    self.view.backgroundColor = [[[NSUserDefaults standardUserDefaults] valueForKey:@"isNight"] integerValue]?[UIColor darkGrayColor]:[UIColor whiteColor];
    self.names = @[@"首页",@"排行榜",@"栏目",@"夜间模式",@"更多内容"];
    [self.tableView reloadData];
    
}
#pragma mark - UITableView
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 2;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    //分两个区, 上面一个区
    return  section?1:self.names.count-1;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    LeftCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    if (indexPath.section==0) {
        cell.imv.image = [UIImage imageNamed:[NSString stringWithFormat:@"%ld",indexPath.row+1]];
        cell.lable.text = self.names[indexPath.row];
        cell.lable.textColor = [[[NSUserDefaults standardUserDefaults] valueForKey:@"isNight"] integerValue]?[UIColor whiteColor]:[UIColor blackColor];
        cell.backgroundColor = [UIColor clearColor];
        if (indexPath.row==3) {
            cell.lable.text = [[[NSUserDefaults standardUserDefaults] valueForKey:@"isNight"] integerValue]?@"夜间模式":@"日间模式";
            cell.imv.image = [[[NSUserDefaults standardUserDefaults] valueForKey:@"isNight"] integerValue]?[UIImage imageNamed:@"night.png"]:[UIImage imageNamed:@"day.png"];
        }
    }else{
        cell.imv.image = [UIImage imageNamed:@"4.png"];
        cell.lable.text = self.names[4];
        cell.lable.textColor = [[[NSUserDefaults standardUserDefaults] valueForKey:@"isNight"] integerValue]?[UIColor whiteColor]:[UIColor blackColor];
        cell.backgroundColor = [UIColor clearColor];
    }
    return cell;
}
/** 点击事件 */
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.section == 0) {
        //首页
        if(indexPath.row == 0){
            ViewController *vc = [ViewController stander];
            UINavigationController *navc = [[UINavigationController alloc]initWithRootViewController:vc];
            navc.navigationBar.barTintColor = [[[NSUserDefaults standardUserDefaults] valueForKey:@"isNight"] integerValue]?[UIColor lightGrayColor]:[UIColor redColor];
            [self.sideMenuViewController setContentViewController:navc];
            [self.sideMenuViewController hideMenuViewController];
        }
        //排行榜
        if(indexPath.row==1){
            HotViewController *vc = [HotViewController stander];
            UINavigationController *navc = [[UINavigationController alloc]initWithRootViewController:vc];
            navc.navigationBar.barTintColor = [[[NSUserDefaults standardUserDefaults] valueForKey:@"isNight"] integerValue]?[UIColor lightGrayColor]:[UIColor redColor];
            [self.sideMenuViewController setContentViewController:navc animated:YES];
            [self.sideMenuViewController hideMenuViewController];
        }
        //栏目
        if(indexPath.row==2){
            SectionListViewController *vc = [SectionListViewController stander];
            UINavigationController *navc = [[UINavigationController alloc]initWithRootViewController:vc];
            navc.navigationBar.barTintColor = [[[NSUserDefaults standardUserDefaults] valueForKey:@"isNight"] integerValue]?[UIColor lightGrayColor]:[UIColor redColor];
            [self.sideMenuViewController setContentViewController:navc animated:YES];
            [self.sideMenuViewController hideMenuViewController];
            
        }
        //夜间模式
        if(indexPath.row==3){
            NSInteger n = ![[[NSUserDefaults standardUserDefaults] valueForKey:@"isNight"] integerValue];
            [[NSUserDefaults standardUserDefaults] setValue:[NSNumber numberWithInteger:n] forKey:@"isNight"];
        }
    }else{
        MoreTabBarController *vc = [MoreTabBarController new];
        UINavigationController *navc = [[UINavigationController alloc]initWithRootViewController:vc];
        navc.navigationBar.barTintColor = [[[NSUserDefaults standardUserDefaults] valueForKey:@"isNight"] integerValue]?[UIColor lightGrayColor]:[UIColor redColor];
        [self.sideMenuViewController setContentViewController:navc animated:YES];
        [self.sideMenuViewController hideMenuViewController];
    }
    
}
kRemoveCellSeparator
//自适应行高
- (CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return UITableViewAutomaticDimension;
}


- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSString *,id> *)change context:(void *)context{
    self.redView.backgroundColor = [change[@"new"] integerValue]?[UIColor lightGrayColor]:[UIColor redColor];
//    self.tableView.backgroundColor = [change[@"new"] integerValue]?[UIColor darkGrayColor]:[UIColor whiteColor];
    self.view.backgroundColor = [change[@"new"] integerValue]?[UIColor darkGrayColor]:[UIColor whiteColor];
    [self.tableView reloadData];
}


- (void)dealloc{
    [[NSUserDefaults standardUserDefaults] removeObserver:self forKeyPath:@"isNight"];
}






@end


























