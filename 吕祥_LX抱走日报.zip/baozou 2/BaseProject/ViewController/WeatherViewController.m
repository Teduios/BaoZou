//
//  WeatherViewController.m
//  BaseProject
//
//  Created by apple-jd40 on 15/11/25.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "WeatherViewController.h"
#import "WeatherViewModel.h"

#define titleBtn_W 80
#define kCollectHeight self.view.bounds.size.height/2

@interface BigWeatherCell : UITableViewCell
/** 显示日期 */
@property (nonatomic, strong) UILabel *dateLb;
/** 天气的图片 */
@property (nonatomic, strong) UIImageView *imv;
/** 最高温和最低温 */
@property (nonatomic, strong) UILabel *temperatureLb;
/** 多云或者晴天啥的 */
@property (nonatomic, strong) UILabel *typeLb;
/** 风力 */
@property (nonatomic, strong) UILabel *fengliLb;
/** 风向 */
@property (nonatomic, strong) UILabel *fengxiangLb;
/** 当前温度 */
@property (nonatomic, strong) UILabel *nowTemperatureLb;
@end
@implementation BigWeatherCell

- (UILabel *)dateLb {
    if(_dateLb == nil) {
        _dateLb = [[UILabel alloc] init];
        [self.contentView addSubview:_dateLb];
        [_dateLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.mas_equalTo(self.contentView.mas_centerX);
            make.top.mas_equalTo(30);
        }];
    }
    return _dateLb;
}

- (UIImageView *)imv {
    if(_imv == nil) {
        _imv = [[UIImageView alloc] init];
        [self.contentView addSubview:_imv];
        [_imv mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.mas_equalTo(self.contentView.mas_centerY);
            make.left.mas_equalTo(40);
            make.size.mas_equalTo(CGSizeMake(90, 120));
        }];
    }
    return _imv;
}

- (UILabel *)temperatureLb {
    if(_temperatureLb == nil) {
        _temperatureLb = [[UILabel alloc] init];
        [self.contentView addSubview:_temperatureLb];
        [_temperatureLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.topMargin.mas_equalTo(self.imv.mas_topMargin);
            make.left.mas_equalTo(self.imv.mas_right).mas_equalTo(20);
        }];
    }
    return _temperatureLb;
}

- (UILabel *)typeLb {
    if(_typeLb == nil) {
        _typeLb = [[UILabel alloc] init];
        [self.contentView addSubview:_typeLb];
        [_typeLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.temperatureLb.mas_bottomMargin).mas_equalTo(5);
            make.left.mas_equalTo(self.imv.mas_right).mas_equalTo(20);
        }];
    }
    return _typeLb;
}

- (UILabel *)fengliLb {
    if(_fengliLb == nil) {
        _fengliLb = [[UILabel alloc] init];
        [self.contentView addSubview:_fengliLb];
        [_fengliLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.imv.mas_right).mas_equalTo(20);
            make.top.mas_equalTo(self.typeLb.mas_bottomMargin).mas_equalTo(5);
        }];
    }
    return _fengliLb;
}

- (UILabel *)fengxiangLb {
    if(_fengxiangLb == nil) {
        _fengxiangLb = [[UILabel alloc] init];
        [self.contentView addSubview:_fengxiangLb];
        [_fengxiangLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.fengliLb.mas_bottomMargin).mas_equalTo(5);
            make.left.mas_equalTo(self.imv.mas_right).mas_equalTo(20);
        }];
    }
    return _fengxiangLb;
}

- (UILabel *)nowTemperatureLb {
    if(_nowTemperatureLb == nil) {
        _nowTemperatureLb = [[UILabel alloc] init];
        [self.contentView addSubview:_nowTemperatureLb];
        _nowTemperatureLb.numberOfLines = 0;
        _nowTemperatureLb.font = [UIFont systemFontOfSize:24 weight:10];
        [_nowTemperatureLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.fengxiangLb.mas_bottomMargin).mas_equalTo(15);
            make.left.mas_equalTo(self.imv.mas_right).mas_equalTo(20);
        }];
    }
    return _nowTemperatureLb;
}
@end
@interface SmallWeatherCell : UITableViewCell
//明日天气
/** 显示日期 */
@property (nonatomic, strong) UILabel *dateLb1;
/** 天气的图片 */
@property (nonatomic, strong) UIImageView *imv1;
/** 明天最高温 */
@property (nonatomic, strong) UILabel *highTemperatureLb1;
/** 后天最低温 */
@property (nonatomic, strong) UILabel *lowTemperatureLb1;
/** 多云或者晴天啥的 */
@property (nonatomic, strong) UILabel *typeLb1;
//后天天气
/** 显示日期 */
@property (nonatomic, strong) UILabel *dateLb2;
/** 天气的图片 */
@property (nonatomic, strong) UIImageView *imv2;
/** 后天最高温 */
@property (nonatomic, strong) UILabel *highTemperatureLb2;
/** 后天最低温 */
@property (nonatomic, strong) UILabel *lowTemperatureLb2;
/** 多云或者晴天啥的 */
@property (nonatomic, strong) UILabel *typeLb2;

@end
@implementation SmallWeatherCell
//明天
- (UIImageView *)imv1 {
    if(_imv1 == nil) {
        _imv1 = [[UIImageView alloc] init];
        [self.contentView addSubview:_imv1];
        [_imv1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(kWindowW/6);
            make.top.mas_equalTo(20);
            make.size.mas_equalTo(CGSizeMake(45, 60));
        }];
    }
    return _imv1;
}
- (UILabel *)dateLb1 {
    if(_dateLb1 == nil) {
        _dateLb1 = [[UILabel alloc] init];
        [self.contentView addSubview:_dateLb1];
        [_dateLb1 mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.left.mas_equalTo(kWindowW/6);
            make.centerX.mas_equalTo(_imv1.mas_centerX);
            make.top.mas_equalTo(_imv1.mas_bottomMargin).mas_equalTo(10);
        }];
    }
    return _dateLb1;
}
- (UILabel *)highTemperatureLb1 {
    if(_highTemperatureLb1 == nil) {
        _highTemperatureLb1 = [[UILabel alloc] init];
        [self.contentView addSubview:_highTemperatureLb1];
        [_highTemperatureLb1 mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.left.mas_equalTo(kWindowW/6);
            make.centerX.mas_equalTo(_imv1.mas_centerX);
            make.top.mas_equalTo(_dateLb1.mas_bottomMargin).mas_equalTo(10);
        }];
    }
    return _highTemperatureLb1;
}
- (UILabel *)lowTemperatureLb1{
    if (_lowTemperatureLb1 == nil) {
        _lowTemperatureLb1 = [UILabel new];
        [self.contentView addSubview:_lowTemperatureLb1];
        [_lowTemperatureLb1 mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.left.mas_equalTo(kWindowW/6);
            make.centerX.mas_equalTo(_imv1.mas_centerX);
            make.top.mas_equalTo(_highTemperatureLb1.mas_bottomMargin).mas_equalTo(10);
        }];
    }
    return _lowTemperatureLb1;
}
- (UILabel *)typeLb1 {
    if(_typeLb1 == nil) {
        _typeLb1 = [[UILabel alloc] init];
        [self.contentView addSubview:_typeLb1];
        [_typeLb1 mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.left.mas_equalTo(kWindowW/6);
            make.centerX.mas_equalTo(_imv1.mas_centerX);
            make.top.mas_equalTo(_lowTemperatureLb1.mas_bottomMargin).mas_equalTo(10);
        }];
    }
    return _typeLb1;
}
//后天
- (UIImageView *)imv2 {
    if(_imv2 == nil) {
        _imv2 = [[UIImageView alloc] init];
        [self.contentView addSubview:_imv2];
        [_imv2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(-kWindowW/6);
            make.top.mas_equalTo(20);
            make.size.mas_equalTo(CGSizeMake(45, 60));
        }];
    }
    return _imv2;
}
- (UILabel *)dateLb2 {
    if(_dateLb2 == nil) {
        _dateLb2 = [[UILabel alloc] init];
        [self.contentView addSubview:_dateLb2];
        [_dateLb2 mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.right.mas_equalTo(-kWindowW/6);
            make.centerX.mas_equalTo(_imv2.mas_centerX);
            make.top.mas_equalTo(_imv2.mas_bottomMargin).mas_equalTo(10);
        }];
    }
    return _dateLb2;
}
- (UILabel *)highTemperatureLb2 {
    if(_highTemperatureLb2 == nil) {
        _highTemperatureLb2 = [[UILabel alloc] init];
        [self.contentView addSubview:_highTemperatureLb2];
        [_highTemperatureLb2 mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.right.mas_equalTo(-kWindowW/6);
            make.centerX.mas_equalTo(_imv2.mas_centerX);
            make.top.mas_equalTo(_dateLb2.mas_bottomMargin).mas_equalTo(10);
        }];
    }
    return _highTemperatureLb2;
}
- (UILabel *)lowTemperatureLb2{
    if (_lowTemperatureLb2 == nil) {
        _lowTemperatureLb2 = [UILabel new];
        [self.contentView addSubview:_lowTemperatureLb2];
        [_lowTemperatureLb2 mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.right.mas_equalTo(-kWindowW/6);
            make.centerX.mas_equalTo(_imv2.mas_centerX);
            make.top.mas_equalTo(_highTemperatureLb2.mas_bottomMargin).mas_equalTo(10);
        }];
    }
    return _lowTemperatureLb2;
}
- (UILabel *)typeLb2 {
    if(_typeLb2 == nil) {
        _typeLb2 = [[UILabel alloc] init];
        [self.contentView addSubview:_typeLb2];
        [_typeLb2 mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.right.mas_equalTo(-kWindowW/6);
            make.centerX.mas_equalTo(_imv2.mas_centerX);
            make.top.mas_equalTo(_lowTemperatureLb2.mas_bottomMargin).mas_equalTo(10);
        }];
    }
    return _typeLb2;
}



@end

@interface WeatherViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) WeatherViewModel *weatherVM;
@property (nonatomic, strong) UIButton *titleBtn;
@property (nonatomic, strong) UITextField *inputTF;
@property (nonatomic, strong) UIView *setCityView;

@end

@implementation WeatherViewController
+ (WeatherViewController *)standerVC{
    static WeatherViewController *vc = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        vc = [[WeatherViewController alloc]init];
    });
    return vc;
}

/** 导航栏中间设置城市的按钮 */
- (UIButton *)titleBtn {
    if(_titleBtn == nil) {
        _titleBtn = [[UIButton alloc] init];
        [_titleBtn setTitle:@"广州" forState:UIControlStateNormal];
        _titleBtn.center = self.navigationController.navigationBar.center;
        _titleBtn.frame = CGRectMake(kWindowW*0.5-titleBtn_W*0.5,15,titleBtn_W, 20);
        [_titleBtn bk_addEventHandler:^(id sender) {
            NSLog(@"头部按钮被点击");
            self.setCityView.hidden = NO;
            self.setCityView.transform = CGAffineTransformMakeTranslation(0, - self.setCityView.bounds.size.height);
            [UIView animateWithDuration:0.3 animations:^{
                self.setCityView.transform = CGAffineTransformMakeTranslation(0, 0);
            }];
        } forControlEvents:UIControlEventTouchUpInside];
    }
    return _titleBtn;
}
/** 点击头部按钮设置城市的一个窗口 */
- (UIView *)setCityView {
    if(_setCityView == nil) {
        _setCityView = [[UIView alloc] init];
        _setCityView.layer.cornerRadius = 30;
        _setCityView.layer.shadowRadius = 30;
        self.setCityView.hidden = YES;
        _setCityView.backgroundColor = [UIColor colorWithRed:0.3 green:0.3 blue:1 alpha:0.9];
        [_setCityView addSubview:self.inputTF];
        [self.inputTF mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(20);
            make.left.mas_equalTo(20);
            make.right.mas_equalTo(-20);
            make.height.mas_equalTo(35);
        }];
        UIButton *bjBtn = [UIButton new];
        bjBtn.backgroundColor = [UIColor colorWithRed:0.4 green:0.4 blue:1 alpha:0.9];
        [bjBtn setTitle:@"北京" forState:UIControlStateNormal];
        [self.setCityView addSubview:bjBtn];
        [bjBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(20);
            make.top.mas_equalTo(self.inputTF.mas_bottomMargin).mas_equalTo(10);
        }];
        [bjBtn bk_addEventHandler:^(id sender) {
            [self.tableView.header beginRefreshing];
            [_titleBtn setTitle:self.inputTF.text forState:UIControlStateNormal];
            [self.weatherVM refreshWeatherWithCity:@"北京" CompleteHandle:^(NSError *error) {
                [self.tableView.header endRefreshing];
                [self.tableView reloadData];
                [self.titleBtn setTitle:@"北京" forState:UIControlStateNormal];
            }];
            [UIView animateWithDuration:0.4 animations:^{
                self.setCityView.transform = CGAffineTransformMakeTranslation(0, -500);
            }];
        } forControlEvents:UIControlEventTouchUpInside];

        UIButton *shBtn = [UIButton new];
        shBtn.backgroundColor = [UIColor colorWithRed:0.4 green:0.4 blue:1 alpha:0.9];
        [shBtn setTitle:@"上海" forState:UIControlStateNormal];
        [self.setCityView addSubview:shBtn];
        [shBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.mas_equalTo(self.inputTF.mas_centerX);
            make.top.mas_equalTo(self.inputTF.mas_bottomMargin).mas_equalTo(10);
        }];
        [shBtn bk_addEventHandler:^(id sender) {
            [self.tableView.header beginRefreshing];
            [_titleBtn setTitle:self.inputTF.text forState:UIControlStateNormal];
            [self.weatherVM refreshWeatherWithCity:@"上海" CompleteHandle:^(NSError *error) {
                [self.tableView.header endRefreshing];
                [self.tableView reloadData];
                [self.titleBtn setTitle:@"上海" forState:UIControlStateNormal];
            }];
            [UIView animateWithDuration:0.4 animations:^{
                self.setCityView.transform = CGAffineTransformMakeTranslation(0, -500);
            }];
        } forControlEvents:UIControlEventTouchUpInside];
        
        UIButton *gzBtn = [UIButton new];
        gzBtn.backgroundColor = [UIColor colorWithRed:0.4 green:0.4 blue:1 alpha:0.9];
        [gzBtn setTitle:@"广州" forState:UIControlStateNormal];
        [self.setCityView addSubview:gzBtn];
        [gzBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(-20);
            make.top.mas_equalTo(self.inputTF.mas_bottomMargin).mas_equalTo(10);
        }];
        [gzBtn bk_addEventHandler:^(id sender) {
            [self.tableView.header beginRefreshing];
            [_titleBtn setTitle:self.inputTF.text forState:UIControlStateNormal];
            [self.weatherVM refreshWeatherWithCity:@"广州" CompleteHandle:^(NSError *error) {
                [self.tableView.header endRefreshing];
                [self.tableView reloadData];
                [self.titleBtn setTitle:@"广州" forState:UIControlStateNormal];
            }];
            [UIView animateWithDuration:0.4 animations:^{
                self.setCityView.transform = CGAffineTransformMakeTranslation(0, -500);
            }];
        } forControlEvents:UIControlEventTouchUpInside];
        
        
        
        UIButton *didSetBtn = [UIButton new];
        [self.setCityView addSubview:didSetBtn];
        didSetBtn.backgroundColor = [UIColor greenColor];
        [didSetBtn setTitle:@"完成" forState:UIControlStateNormal];
        [didSetBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.bottom.mas_equalTo(-20);
            make.size.mas_equalTo(CGSizeMake(50, 30));
        }];
        [didSetBtn bk_addEventHandler:^(id sender) {
            if (self.inputTF.text!=nil&&![self.inputTF.text isEqualToString:@""]) {
                [self.tableView.header beginRefreshing];
                [_titleBtn setTitle:self.inputTF.text forState:UIControlStateNormal];
                    [self.weatherVM refreshWeatherWithCity:self.titleBtn.titleLabel.text CompleteHandle:^(NSError *error) {
                        [self.tableView.header endRefreshing];
                        [self.tableView reloadData];
                        self.inputTF.text = nil;
                    }];
            }
            [UIView animateWithDuration:0.4 animations:^{
                self.setCityView.transform = CGAffineTransformMakeTranslation(0, -500);
            }];
        } forControlEvents:UIControlEventTouchUpInside];

    }
    return _setCityView;
}
/** 天气模型懒加载 */
- (WeatherViewModel *)weatherVM{
    if (_weatherVM == nil) {
        _weatherVM = [WeatherViewModel new];
    }
    return _weatherVM;
}
/** tableview懒加载 */
- (UITableView *)tableView{
    if (_tableView == nil) {
        _tableView = [UITableView new];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.allowsSelection = NO;
        _tableView.scrollEnabled = NO;
        [self.view addSubview:_tableView];
        _tableView.separatorColor = [UIColor clearColor];
        _tableView.backgroundColor = [UIColor clearColor];
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        [_tableView registerClass:[BigWeatherCell class] forCellReuseIdentifier:@"Cell"];
        [_tableView registerClass:[SmallWeatherCell class] forCellReuseIdentifier:@"smallCell"];
    }
    return _tableView;
}
/** 弹出的输入城市的TextField */
- (UITextField *)inputTF {
    if(_inputTF == nil) {
        _inputTF = [[UITextField alloc] init];
        _inputTF.placeholder = @"请输入要查询的城市";
        _inputTF.backgroundColor = [UIColor colorWithRed:0.2 green:0.4 blue:1 alpha:1];
    }
    return _inputTF;
}
- (void)viewDidLoad{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithRed:220/255.0 green:230/255.0 blue:253/255.0 alpha:1];
//    self.view.backgroundColor = [UIColor darkGrayColor];
    self.title = @"天气";
    self.tableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self.weatherVM refreshWeatherWithCity:self.titleBtn.titleLabel.text CompleteHandle:^(NSError *error) {
            [_tableView.header endRefreshing];
            [_tableView reloadData];
        }];
    }];
    [self.tableView.header beginRefreshing];
}
#pragma mark - UITableView 协议
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 2;
}
//行高 = 屏幕高度 - 顶部导航 - 底部TabBar / 2
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return (kWindowH - [self.topLayoutGuide length] - [self.bottomLayoutGuide length])/2;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    //如果是第一行
    if (indexPath.row == 0) {
    BigWeatherCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
//    cell.backgroundColor = [UIColor colorWithRed:21/255.0 green:120/255.0 blue:253/255.0 alpha:1];
    cell.backgroundColor = [UIColor clearColor];
    cell.dateLb.text = [_weatherVM getDateWithType:Today];
    cell.temperatureLb.text = [NSString stringWithFormat:@"最%@/最%@",[self.weatherVM getHighTemperatureWithType:Today],[_weatherVM getLowTemperatureWithType:Today]];
    cell.typeLb.text = [_weatherVM getTypeWithType:Today];
    cell.fengliLb.text = [_weatherVM getFengliWithType:Today];
    cell.fengxiangLb.text = [_weatherVM getFengxiangWithType:Today];
    cell.nowTemperatureLb.text = [NSString stringWithFormat:@"%@°C",[_weatherVM getNowTempetatureWithType:Today]];
    if (_weatherVM.weatherData==nil)cell.nowTemperatureLb.text = @"无此城市";
        cell.imv.image = [_weatherVM getImageForTypeWithType:Today];
    [cell.contentView addSubview:self.setCityView];
    [self.setCityView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(cell.contentView);
        make.top.mas_equalTo(0);
        make.size.mas_equalTo(CGSizeMake(200, 150));
    }];
    [cell.contentView addSubview:self.titleBtn];
    [self.titleBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(cell.imv.mas_centerX).mas_equalTo(0);
        make.centerY.mas_equalTo(cell.dateLb.mas_centerY).mas_equalTo(0);
    }];
        return cell;
    }else{//总共两行,不然就是第二行
        SmallWeatherCell *cell = [tableView dequeueReusableCellWithIdentifier:@"smallCell"];
        cell.backgroundColor = [UIColor clearColor];
        //明天
        cell.imv1.image = [_weatherVM getImageForTypeWithType:Tomorrow];
        cell.dateLb1.text = [_weatherVM getDateWithType:Tomorrow];
        cell.highTemperatureLb1.text = [NSString stringWithFormat:@"最%@",[_weatherVM getHighTemperatureWithType:Tomorrow]];
        cell.lowTemperatureLb1.text = [NSString stringWithFormat:@"最%@",[_weatherVM getLowTemperatureWithType:Tomorrow]];
        cell.typeLb1.text = [_weatherVM getTypeWithType:Tomorrow];
        //后天
        cell.imv2.image = [_weatherVM getImageForTypeWithType:TheDayAfterTomorrow];
        cell.dateLb2.text = [_weatherVM getDateWithType:TheDayAfterTomorrow];
        cell.highTemperatureLb2.text = [NSString stringWithFormat:@"最%@",[_weatherVM getHighTemperatureWithType:TheDayAfterTomorrow]];
        cell.lowTemperatureLb2.text = [NSString stringWithFormat:@"最%@",[_weatherVM getLowTemperatureWithType:TheDayAfterTomorrow]];
        cell.typeLb2.text = [_weatherVM getTypeWithType:TheDayAfterTomorrow];

        return cell;
    }
}












































@end



