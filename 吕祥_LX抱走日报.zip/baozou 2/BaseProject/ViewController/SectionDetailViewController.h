//
//  SectionDetailViewController.h
//  BaseProject
//
//  Created by apple-jd40 on 15/11/15.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"
@interface SectionDetailViewController : BaseViewController

@property (nonatomic, strong) NSNumber *Id;
@property (nonatomic, strong) NSString *sectionName;

@end
