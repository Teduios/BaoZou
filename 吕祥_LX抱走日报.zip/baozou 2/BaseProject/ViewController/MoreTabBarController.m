//
//  MoreTabBarController.m
//  BaseProject
//
//  Created by apple-jd40 on 15/11/23.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "MoreTabBarController.h"
#import "Factory.h"
#import "WeatherViewController.h"
#import "HotViewController.h"

@interface MoreTabBarController ()

@end

@implementation MoreTabBarController

- (void)viewDidLoad {
    [super viewDidLoad];
    [[NSUserDefaults standardUserDefaults] addObserver:self forKeyPath:@"isNight" options:NSKeyValueObservingOptionNew context:nil];
    self.view.backgroundColor = [[[NSUserDefaults standardUserDefaults] valueForKey:@"isNight"] integerValue]?[UIColor darkGrayColor]:[UIColor whiteColor];
    self.tabBar.backgroundColor = [[[NSUserDefaults standardUserDefaults] valueForKey:@"isNight"] integerValue]?[UIColor lightGrayColor]:[UIColor whiteColor];
    [Factory addMenuItemToVC:self];
    
    self.viewControllers = @[[WeatherViewController standerVC],[HotViewController stander]];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}
//观察者
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSString *,id> *)change context:(void *)context{
    self.navigationController.navigationBar.barTintColor = [change[@"new"] integerValue]?[UIColor lightGrayColor]:[UIColor redColor];
    self.view.backgroundColor = [change[@"new"] integerValue]?[UIColor darkGrayColor]:[UIColor whiteColor];
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
