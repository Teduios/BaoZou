//
//  BaseViewController.m
//  BaseProject
//
//  Created by apple-jd40 on 15/11/19.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewController.h"

@interface BaseViewController ()

@end

@implementation BaseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setColor];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)setColor{
    //NSLog(@"coooooooooooooooooooooooooooooooooooolor");
    if ([[NSUserDefaults standardUserDefaults] valueForKey:@"isNight"]==nil) {
        [[NSUserDefaults standardUserDefaults] setValue:@0 forKey:@"isNight"];
    }
    //观察
    [[NSUserDefaults standardUserDefaults] addObserver:self forKeyPath:@"isNight" options:NSKeyValueObservingOptionNew context:nil];
    //导航栏设置为红色
    self.navigationController.navigationBar.barTintColor = [[[NSUserDefaults standardUserDefaults] valueForKey:@"isNight"] integerValue]?[UIColor lightGrayColor]:[UIColor redColor];

}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
