//
//  SecionListViewController.h
//  BaseProject
//
//  Created by apple-jd40 on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"
@interface SectionListViewController : BaseViewController
+ (SectionListViewController *)stander;
@end
