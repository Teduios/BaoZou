

#import "ViewController.h"
#import "ListViewModel.h"
#import "HotListCell.h"
#import "iCarousel.h"
#import "DetailViewController.h"
#import "NewsModel.h"
#import "LXImageView.h"
#import "Factory.h"
#define headerViewHeight kWindowW/2

@interface ViewController ()<UITableViewDelegate,UITableViewDataSource,iCarouselDelegate,iCarouselDataSource>

@property (nonatomic, strong) iCarousel *ic;
@property (nonatomic, strong) ListViewModel *ListVM;
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) UIView *headerView;

@end

@implementation ViewController

{
    UIPageControl *_pageControl;
    UILabel *_titleLb;
    NSTimer *_timer;
}

+ (ViewController *)stander{
    static ViewController *vc = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        vc = [ViewController new];
        //vc.navigationController.navigationBar.barTintColor = [[[NSUserDefaults standardUserDefaults] valueForKey:@"isNight"] integerValue]?[UIColor redColor]:[UIColor lightGrayColor];
    });
    return vc;
}

- (ListViewModel *)ListVM{
    if(_ListVM==nil){
        _ListVM = [ListViewModel new];
    }
    return _ListVM;
}
- (UITableView *)tableView{
    if (_tableView==nil) {
        _tableView = [UITableView new];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.backgroundColor = [UIColor clearColor];
        [_tableView registerClass:[HotListCell class] forCellReuseIdentifier:@"Cell"];
        [self.view addSubview:_tableView];
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
    }
    return _tableView;
}
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    self.view.backgroundColor = [[[NSUserDefaults standardUserDefaults] valueForKey:@"isNight"] integerValue]?[UIColor darkGrayColor]:[UIColor whiteColor];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    //self.navigationController.navigationBar.barTintColor = [[[NSUserDefaults standardUserDefaults] valueForKey:@"isNight"] integerValue]?[UIColor lightGrayColor]:[UIColor redColor];
    self.view.backgroundColor = [[[NSUserDefaults standardUserDefaults] valueForKey:@"isNight"] integerValue]?[UIColor darkGrayColor]:[UIColor whiteColor];
    self.tableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self.ListVM refreshDataCompleteHandle:^(NSError *error) {
            self.tableView.tableHeaderView = self.headerView;
            [_tableView.header endRefreshing];
            [self.ListVM getYesterdayDataCompleteHandle:^(NSError *error) {
                [_tableView reloadData];
            }];
        }]; 
    }];
    [_tableView.header beginRefreshing];
    _tableView.footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        [self.ListVM getMoreDataCompleteHandle:^(NSError *error) {
            if (error) {
                [self showErrorMsg:error.description];
            }
            [_tableView.footer endRefreshing];
            [_tableView reloadData];
        }];
    }];
    [Factory addMenuItemToVC:self];
    self.title = @"暴走日报";
}

#pragma mark - 实现协议 UITableView
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return self.ListVM.rowNumber;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    HotListCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    [cell.imv setImageWithURL:[NSURL URLWithString:[self.ListVM imageURLStringForRow:indexPath.section]]];
    cell.titleLb.text    = [self.ListVM titleForRow:indexPath.section];
    cell.sectionLb.text  = [self.ListVM sectionNameForRow:indexPath.section];
    cell.hitcountLb.text = [self.ListVM hitForRow:indexPath.section];
    cell.backgroundColor = [UIColor clearColor];
    return cell;
}
/** 分区高 */
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 10.0;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, tableView.bounds.size.width, 10)];
    view.backgroundColor = [[[NSUserDefaults standardUserDefaults] valueForKey:@"isNight"] integerValue]?[UIColor lightGrayColor]:[UIColor colorWithRed:0 green:0 blue:0 alpha:0.1];
    return view;
}

/** 行高 */
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 110;
}
/** 点击事件 */
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    DetailViewController *vc = [[DetailViewController alloc]init];
    vc.url = [self.ListVM shareURLForRow:indexPath.section];
    [self.navigationController pushViewController:vc animated:YES];
}


#pragma mark - iCarousel协议
- (NSInteger)numberOfItemsInCarousel:(iCarousel *)carousel{
    return self.ListVM.topStories.count;
}
- (UIView *)carousel:(iCarousel *)carousel viewForItemAtIndex:(NSInteger)index reusingView:(UIImageView *)view{
    if (view==nil) {
        view = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, kWindowW, headerViewHeight)];
        view.contentMode = 2 ;
        view.clipsToBounds = YES;
    }
    NSURL *url = [self.ListVM topImageURl:index];
    [view setImageWithURL:url];
    
    return view;
}
- (void)carousel:(iCarousel *)carousel didSelectItemAtIndex:(NSInteger)index{
    DetailViewController *vc = [[DetailViewController alloc]init];
    vc.url = [self.ListVM topWebURLForRow:index];
    [self.navigationController pushViewController:vc animated:YES];
}
-(CGFloat)carousel:(iCarousel *)carousel valueForOption:(iCarouselOption)option withDefault:(CGFloat)value{
    if (option == iCarouselOptionWrap) {
        return YES;
    }
    return value;
}

/** 头部视图 */
-(UIView *)headerView{
    if (_headerView==nil) {
        NSLog(@"dsd");
        //[_timer invalidate];
        //头部视图origin无效,宽度无效,肯定是与table同宽
        _headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 0, headerViewHeight)];
        _ic = [iCarousel new];
        [_headerView addSubview:_ic];
        [_ic mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        _ic.delegate = self;
        _ic.dataSource = self;
        _ic.type = 0;
        _ic.pagingEnabled = YES;
        _ic.scrollSpeed = 10;
        //开启定时器
        _timer = [NSTimer bk_scheduledTimerWithTimeInterval:5 block:^(NSTimer *timer) {
            [_ic scrollToItemAtIndex:_ic.currentItemIndex+1 animated:YES];
        } repeats:YES];
        //头部标签
        _titleLb = [UILabel new];
        _titleLb.textColor = [UIColor whiteColor];
        _titleLb.numberOfLines = 0;
        _titleLb.font = [UIFont systemFontOfSize:19 weight:10];
        [_headerView addSubview:_titleLb];
        [_titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(20);
            make.right.mas_equalTo(-15);
            make.bottom.mas_equalTo(-25);
        }];
        _titleLb.text = [self.ListVM headerStringForRow:0];
        
        
        _pageControl = [UIPageControl new];
        _pageControl.numberOfPages = self.ListVM.topStories.count;
        [_headerView addSubview:_pageControl];
        [_pageControl mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.mas_equalTo(10);
            make.centerX.mas_equalTo(0);
        }];
        _pageControl.userInteractionEnabled = NO;//关闭用户交互
    }
    return _headerView;
}
//当前滚动到第几个
- (void)carouselCurrentItemIndexDidChange:(iCarousel *)carousel{
    _titleLb.text = [self.ListVM headerStringForRow:_ic.currentItemIndex];
    _pageControl.currentPage = _ic.currentItemIndex;
}
//观察者
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSString *,id> *)change context:(void *)context{
    //staus  dic 白天:wenzi : sdsd  晚上: wenzi ss dic[staus]=
    self.navigationController.navigationBar.barTintColor = [change[@"new"] integerValue]?[UIColor lightGrayColor]:[UIColor redColor];
    self.view.backgroundColor = [change[@"new"] integerValue]?[UIColor darkGrayColor]:[UIColor whiteColor];
    [self.tableView reloadData];
}

- (void)dealloc{
    [[NSUserDefaults standardUserDefaults] removeObserver:self forKeyPath:@"isNight"];
}


@end




















