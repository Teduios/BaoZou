//
//  BaseViewController.h
//  BaseProject
//
//  Created by apple-jd40 on 15/11/19.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseViewController : UIViewController
- (void)setColor;
@end
